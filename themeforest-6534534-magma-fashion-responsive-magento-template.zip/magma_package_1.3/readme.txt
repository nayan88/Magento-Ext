
You can see instruction in documentation\template\index.html file
Configuration products display in extensions: documenttation\extensions folder



Changlog
18/01/2014
Fixed Checkout bug in Magento 1.8
Files modified
	app/design/frontend/magma/default/layout/checkout.xml
	app/design/frontend/magma/default/template/checkout/onepage/payment.html



Changlog
26/01/2014
Error Fixed (System.log Errors)
Files Changed/Modified
	app/design/frontend/magma/default/layout/ajaxcartsupper.xml
	app/design/frontend/magma/default/layout/layernavigationajax.xml
	app/design/frontend/magma/default/template/page/switch/flags.phtml
	app/design/frontend/magma/default/template/w3themes/brandslider/brandslider.phtml





Changlog
11/02/2014
Added Inner Zoom (On Product page)
Files Changed/Modified
	app/code/local/W3Themes/Prozoom/etc/config.xml
	app/code/local/W3Themes/Prozoom/etc/system.xml
	app/code/local/W3Themes/Prozoom/Model/Config/Type.php
	app/design/frontend/magma/default/template/w3themes/prozoom/media.phtml
	js/w3themes/prozoom/zoom.js



Changlog
13/02/2014
Minor Bug Fixes.
Files Changed/Modified
	js/w3themes/ajax_cart_super.js
	## For Magento 1.8+ Only
	app/design/frontend/magma/default/template/checkout/cart.phtml



Changlog
28/02/2014
Added Custom Mennu (MegaMenu)
Files Changed/Modified
	app/code/local/W3Themes/Custommenu/*all
	app/design/adminhtml/default/default/layout/custommenu.xml
	app/design/frontend/magma/default/layout/custommenu.xml
	app/design/frontend/magma/default/template/w3themes/custommenu/custommenu.phtml
	js/w3themes/custommenu/custommenu.js
	skin/frontend/magma/default/w3themes/css/custommenu.css




Changlog
18/03/2014
Added One Page Checkout (Swift Checkout)
Files Added/Changed/Modified
	app/design/frontend/magma/default/template/onepagecheckout/onepagecheckout.phtml
	skin/frontend/magma/default/css/onepagecheckout.css
	skin/frontend/magma/default/images/onepagecheckout/*